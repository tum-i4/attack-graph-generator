package service.a.service;

/**
 * @author Oreste Luci
 */
public class AbstractService {
    public static final String CLIENT_SERVICE = "serviceB";
}
