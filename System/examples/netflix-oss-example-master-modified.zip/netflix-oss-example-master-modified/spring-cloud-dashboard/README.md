#Spring Cloud Dashboard

This a GUI for administrating Spring Cloud Applications.

For more info see the [spring-cloud-dashboard](https://github.com/VanRoy/spring-cloud-dashboard) project.

##Quick Start
 
To compile:
 
```ShellSession
mvn clean package
```
 
To execute:
 
```ShellSession
java -jar target/spring-cloud-dashboard.jar
```
 
To open the Dashboard 
 
```
http://localhost:8086/
```
 