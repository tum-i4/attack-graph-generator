#!/bin/bash

echo "Running application"
java -jar spring-cloud-dashboard.jar