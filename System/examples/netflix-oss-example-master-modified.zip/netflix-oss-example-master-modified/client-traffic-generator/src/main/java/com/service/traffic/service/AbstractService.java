package com.service.traffic.service;

/**
 * Created by mnavarro on 25.06.15.
 */
public abstract class AbstractService {

    public static final String CLIENT_SERVICE = "serviceA";
}
