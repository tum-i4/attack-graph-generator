#!/bin/sh

exec ${CATALINA_HOME}/bin/catalina.sh jpda run
